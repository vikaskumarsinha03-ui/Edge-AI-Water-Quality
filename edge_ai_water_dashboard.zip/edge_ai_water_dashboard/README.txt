# Edge-AI Water Spectral Monitor

## Run locally
1. Install Python 3.10+.
2. Open a terminal in this folder.
3. Create an environment (recommended):
   - Windows: `py -m venv .venv`
   - Windows PowerShell: `.venv\Scripts\Activate.ps1`
4. Install dependencies:
   `python -m pip install -r requirements.txt`
5. Start the dashboard:
   `python -m streamlit run app.py`

## CSV input
Required columns:
`sample_id,FZ,FY,FXL,NIR,VIS1L,VIS1R,F2,F3,F4,F6,VIS2L,VIS2R,F1,F7,F8,F5,VIS3L,VIS3R`

One row should represent one complete spectral reading. Additional columns are allowed.

If no CSV is uploaded, the app displays synthetic demonstration data. This data is clearly labelled and must not be reported as real experimental data.

## Model caveat
Isolation Forest flags unusual spectra relative to the data provided. It does not determine whether water is safe, nor does it directly measure turbidity, pH, TDS, or contamination.
